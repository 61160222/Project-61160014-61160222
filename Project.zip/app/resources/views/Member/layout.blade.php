<!DOCTYPE html>
<html>
<head>
    <title>Member</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>
<div>
    <div class="container">
        @yield('content')
    </div>
</div>
   
</body>
</html>
