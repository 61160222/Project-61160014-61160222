

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=KoHo:wght@200;500&family=Prompt:wght@300;400&display=swap"
    rel="stylesheet">

<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <font face="Prompt">
                    <br><br>
                    <font size=7><B>Edit Order</B></font><br>
                    <form action="<?php echo e(route('order.update',$OR->OrderNumber)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <table height="400" width="800">
                            <tr>
                                <td> Member : </td>
                                <td><input type=text name=Mem_ID value="<?php echo e($OR->Mem_ID); ?>" style="width:500px;" readonly></td>
                            </tr>
                            <tr>
                                <td> Order Number : </td>
                                <td><input type=text name=OrderNumber value="<?php echo e($OR->OrderNumber); ?>" style="width:500px;" readonly></td>
                            </tr>
                            <tr>
                                <td> Book Code : </td>
                                <td><input type=text name=BookCodeO value="<?php echo e($OR->BookCodeO); ?>"
                                        style="width:500px;"></td>
                            </tr>
                            <tr>
                                <td> Book Name : </td>
                                <td><input type=text value="<?php echo e($OR->BookName); ?>" style="width:500px;" readonly>
                                </td>
                            </tr>
                            <tr>
                                <td> Book Price : </td>
                                <td><input type=text value="<?php echo e($OR->BookPrice); ?>" style="width:500px;" readonly>
                                </td>
                            </tr>
                            <tr>
                                <td> Order Uint : </td>
                                <td><input type=text name=OrderUint value="<?php echo e($OR->OrderUint); ?>" style="width:500px;"></td>
                            </tr>

                            <tr align="center">
                                <td colspan=2>
                                    <button class="btn btn-primary" href="<?php echo e(route('order.index')); ?>">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Edit</button>
                                </td>
                            </tr>
                        </table>
                    </form>
                </font>
                <div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Order.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/order/edit.blade.php ENDPATH**/ ?>