

<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=KoHo:wght@200;500&family=Prompt:wght@300;400&display=swap"
    rel="stylesheet">

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <font face="Prompt">

                    <table border=1 align="center">
                        <font size=7><B><u>Order List </u></B></font>
                        <tr align="center">
                            <td width="150">Username</td>
                            <td width="150">Order Number</td>
                            <td width="150">Book Code</td>
                            <td width="150">Book Name</td>
                            <td width="150">Total Unit</td>
                            <td width="150">Total Price</td>
                        </tr>
                        <?php $__currentLoopData = $orderdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $OD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr align="center">
                            <td><?php echo e($OD->Username); ?></td>
                            <td><?php echo e($OD->OrderNumber); ?></td>
                            <td><?php echo e($OD->BookCode); ?></td>
                            <td><?php echo e($OD->BookName); ?></td>
                            <td><?php echo e($OD->TUnit); ?></td>
                            <td><?php echo e($OD->TPrice); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <button align="right" action="<?php echo e(route('orderdetail.index' )); ?>">Back</button>
                </font>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('OrderDetail.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/orderdetail/show.blade.php ENDPATH**/ ?>