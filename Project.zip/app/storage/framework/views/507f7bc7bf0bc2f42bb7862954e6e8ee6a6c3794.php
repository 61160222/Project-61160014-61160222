

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        
        <div class="panel panel-default">
            <div class="panel-heading">
                <div>
                    <a class="btn btn-primary" href="<?php echo e(route('Staff.create')); ?>">Create</a>
                </div>
                <table border=1>
                    <tr>
                        <td>Staff No</td>
                        <td>ชื่อ</td>
                        <td>นาลสกุล</td>
                        <td>ที่อยู่</td>
                        <td>E-mail</td>
                        <td>เบอร์โทรศัพท์</td>
                        <td>การดำเนินงาน</td>
                    </tr>
                    <?php $__currentLoopData = $Staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Sta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td><?php echo e($Sta->Staff_No); ?></td>
                        <td><?php echo e($Sta->Staff_Name); ?></td>
                        <td><?php echo e($Sta->Staff_Surname); ?></td>
                        <td><?php echo e($Sta->Staff_Address); ?></td>
                        <td><?php echo e($Sta->Staff_Email); ?></td>
                        <td><?php echo e($Sta->Staff_Phone); ?></td>
                        <td>
                        </form>
                        <a class="btn btn-primary" href="<?php echo e(route ('Staff.edit',$Sta->Staff_No)); ?>">Edit</a>
                        </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/Staff/index.blade.php ENDPATH**/ ?>