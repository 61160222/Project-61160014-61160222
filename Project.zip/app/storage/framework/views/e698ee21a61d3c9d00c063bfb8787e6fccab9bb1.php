<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        
            <div class="panel panel-default">
            <div class="panel-heading">
                <div>
                    <a class="btn btn-primary" href="<?php echo e(route('account.create')); ?>">เปิดบัญชี</a>
                    <a class="btn btn-primary" href="">โอนเงิน</a>
                    <a class="btn btn-primary" href="<?php echo e(route('account.calculaterate')); ?>">คำนวณภาษี</a>
                </div>
                <table border=1>
                <tr>
                <td>เลขบัญชี</td>
                <td>ชนิดบบัญชี</td>
                <td>ชื่่อ</td>
                <td>นาลสกุล</td>
                <td>ที่อยู่</td>
                <td>ตำบล</td>
                <td>อำเภอ</td>
                <td>จังหวัด</td>
                <td>รหัสไปราณีย์</td>
                <td>วันที่เปิดบัญชี</td>
                <td>จำนวนเงิน</td>
                <td>การดำเนินงาน</td>

                </tr>
                <?php $__currentLoopData = $account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <tr>
                <td><?php echo e($acc->ACC_No); ?></td>
                <td><?php echo e($acc->Type_No); ?></td>
                <td><?php echo e($acc->ACC_Name); ?></td>
                <td><?php echo e($acc->ACC_Surname); ?></td>
                <td><?php echo e($acc->Address); ?></td>
                <td><?php echo e($acc->SubDistrict); ?></td>
                <td><?php echo e($acc->District); ?></td>
                <td><?php echo e($acc->Province); ?></td>
                <td><?php echo e($acc->ZipCode); ?></td>
                <td><?php echo e($acc->DateOp); ?></td>
                <td><?php echo e($acc->Balance); ?></td>
                <td>
                <form action="<?php echo e(route('account.destroy',$acc->ACC_No)); ?>" method="POST">
                <a class="btn btn-primary" href="<?php echo e(route ('account.edit',$acc->ACC_No)); ?>">Edit</a>
                <a class="btn btn-success" href="<?php echo e(route ('account.deposit',$acc->ACC_No)); ?>">Deposit</a>
                <a class="btn btn-warning" href="<?php echo e(route ('account.withdraw',$acc->ACC_No)); ?>">Withdraw</a>
                <?php echo csrf_field(); ?>
                <?php echo method_field("DELETE"); ?>
                <button type="submit" class="btn btn-danger">Delete</button>
                </form>
                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/account/index.blade.php ENDPATH**/ ?>