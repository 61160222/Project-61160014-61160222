

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $B): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=KoHo:wght@200;500&family=Prompt:wght@300;400&display=swap"
    rel="stylesheet">

<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <font face="Prompt">
                    <br><br>
                    <font size=7><B>Edit Book</B></font><br>
                    <form action="<?php echo e(route('book.update',$B->BookCode)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <table height="400" width="800">
                            <tr>
                                <td border=1> CodeBook : </td>
                                <td><input type=text name=BookCode value="<?php echo e($B->BookCode); ?>" style="width:500px;"></td>
                            </tr>
                            <tr>
                                <td> BookName : </td>
                                <td><input type=text name=BookName value="<?php echo e($B->BookName); ?>" style="width:500px;"></td>
                            </tr>
                            <tr>
                                <td> BoookTypeID : </td>
                                <td><input type=text name=BookTypeCode value="<?php echo e($B->BookTypeCode); ?>"
                                        style="width:500px;"></td>
                            </tr>
                            <tr>
                                <td> Price : </td>
                                <td><input type=text name=BookPrice value="<?php echo e($B->BookPrice); ?>" style="width:500px;">
                                </td>
                            </tr>
                            <tr>
                                <td> Stock : </td>
                                <td><input type=text name=BookStock value="<?php echo e($B->BookStock); ?>" style="width:500px;">
                                </td>
                            </tr>
                            <tr>
                                <td> Author : </td>
                                <td><input type=text name=BooktAuthor value="<?php echo e($B->BooktAuthor); ?>"
                                        style="width:500px;"></td>
                            </tr>
                            <tr>
                                <td> Note : </td>
                                <td><input type=text name=BookNote value="<?php echo e($B->BookNote); ?>" style="width:600px; ">
                                </td>
                            </tr>
                            <tr align="center">
                                <td colspan=2>
                                    <button class="btn btn-primary" href="<?php echo e(route('book.index')); ?>">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Edit</button>
                                </td>
                            </tr>
                        </table>
                    </form>
                </font>
                <div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Book.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/book/edit.blade.php ENDPATH**/ ?>