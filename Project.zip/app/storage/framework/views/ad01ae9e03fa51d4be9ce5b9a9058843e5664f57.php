

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <table border=1>
                <tr>
                <td>ID</td>
                <td>ชื่อ</td>
                <td>อีเมลล์</td>
                <td>ยืนยันอีเมลที่</td>
                <td>จำโทเค็น</td>
                <td>สร้างเมื่อ</td>
                <td>ปรับปรุงเมื่อ</td>

                </tr>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <tr>
                <td><?php echo e($acc->id); ?></td>
                <td><?php echo e($acc->name); ?></td>
                <td><?php echo e($acc->email); ?></td>
                <td><?php echo e($acc->email_verified_at); ?></td>
                <td><?php echo e($acc->remember_token); ?></td>
                <td><?php echo e($acc->created_at); ?></td>
                <td><?php echo e($acc->updated_at); ?></td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/users/index.blade.php ENDPATH**/ ?>