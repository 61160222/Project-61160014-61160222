

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $Staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Sta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <div>
                แก้ไขข้อมูลบัญชี
                </div>
                <form action="<?php echo e(route('Staff.update',$Sta->Staff_No)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field("PUT"); ?>
                <table border=1>
                <tr>
                    <td>เลขที่ผู้ดูแล :</td>
                    <td><input type=text name=Staff_No value="<?php echo e($Sta->Staff_No); ?>"></td>
                </tr>
                <tr>
                    <td>ชื่อ:</td>
                    <td><input type=text name=Staff_Name value="<?php echo e($Sta->Staff_Name); ?>"></td>
                </tr>
                <tr>
                    <td>นามสกุล :</td>
                    <td><input type=text name=Staff_Surname value="<?php echo e($Sta->Staff_Surname); ?>"></td>
                </tr>
                <tr>
                    <td>ที่อยู่:</td>
                    <td><input type=text name=Staff_Address value="<?php echo e($Sta->Staff_Address); ?>"></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><input type=text name=Staff_Email value="<?php echo e($Sta->Staff_Email); ?>"></td>
                </tr>
                <tr>
                    <td>เบอร์โทร:</td>
                    <td><input type=text name=Staff_Phone value="<?php echo e($Sta->Staff_Phone); ?>"></td>
                </tr>
                <tr>

                <td colspan=2>
                    <button type="reset" class="btn btn-primary">ยกเลิก</button>
                    <button type="submit" class="btn btn-primary">แก้ไขข้อมูล</button>

                </td>
                </tr>
                </table>
               </form>
               <div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/Staff/edit.blade.php ENDPATH**/ ?>