

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <div>
                เปิดบัญชีใหม่
                </div>

                <form action="<?php echo e(route('Staff.store')); ?>" method="POST">
                
                <?php echo csrf_field(); ?>
                <?php echo method_field("POST"); ?>

                <table border=1>
                <tr>
                    <td>Staff No :</td>
                    <td><input type=text name=Staff_No></td>
                </tr>
                <tr>
                    <td>ชื่อ :</td>
                    <td><input type=text name=Staff_Name></td>
                </tr>
                <tr>
                    <td>นามสกุล :</td>
                    <td><input type=text name=Staff_Surname></td>
                </tr>
                <tr>
                    <td>ที่อยู่ :</td>
                    <td><input type=text name=Staff_Address></td>
                </tr>
                <tr>
                    <td>E-mail :</td>
                    <td><input type=text name=Staff_Email></td>
                </tr>
                <tr>
                    <td>เบอร์โทรศัพท์ :</td>
                    <td><input type=text name=Staff_Phone></td>
                </tr>
                
                <tr>
                <td colspan=2>
                    <button type="reset" class="btn btn-primary">ยกเลิก</button>
                    <button type="submit" class="btn btn-primary">บันทึกข้อมูล</button>

                </td>
                </tr>
                
                </table>
               </form>
               <div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/Staff/create.blade.php ENDPATH**/ ?>