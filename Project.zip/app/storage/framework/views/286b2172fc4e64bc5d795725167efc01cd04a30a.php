<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $transfer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TF): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=KoHo:wght@200;500&family=Prompt:wght@300;400&display=swap"
    rel="stylesheet">

<div class="container">
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                <font face="Prompt">
                    <br><br>
                    <font size=7><B>Edit Shopping</B></font><br>
                    <form action="<?php echo e(route('transfer.update',$TF->TransferOrder)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <table height="400" width="800">
                            <tr>
                                <td border=1> Transfer Order : </td>
                                <td><input type=text name=TransferOrder value="<?php echo e($TF->TransferOrder); ?>"
                                        style="width:500px;"></td>
                            </tr>
                            <tr>
                                <td> Transfer Date : </td>
                                <td><input type=text name=TransferDate value="<?php echo e($TF->TransferDate); ?>"
                                        style="width:500px;"></td>
                            </tr>
                            <tr>
                                <td><label for="bank"> Bank Name :</label></td>
                                <td><select name=BankName id="bank" style="width:500px;">
                                        <option value="<?php echo e($TF->BankName); ?>">- Choose -</option>
                                        <option value="SCB">SCB</option>
                                        <option value="BOTH">BOTH</option>
                                        <option value="BBL">BBL</option>
                                        <option value="KTB">KTB</option>
                                        <option value="KBANK">KBANK</option>
                                        <option value="TMB">TMB</option>
                                        <option value="UOBT">UOBT</option>
                                        <option value="BAAC">BAAC</option>
                                        <option value="GSB">GSB</option>
                                        <option value="ISBT">ISBT</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td> Bank Branch : </td>
                                <td><input type=text name=BankBranch value="<?php echo e($TF->BankBranch); ?>" style="width:500px;">
                                </td>
                            </tr>
                            <tr>
                                <td> Balance : </td>
                                <td><input type=text name=TotalBalance value="<?php echo e($TF->TotalBalance); ?>"
                                        style="width:500px; ">
                                </td>
                            </tr>
                            <tr align="center">
                                <td colspan=2>
                                    <button class="btn btn-primary" href="<?php echo e(route('transfer.index')); ?>">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Edit</button>
                                </td>
                            </tr>
                        </table>
                    </form>
                </font>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Transfer.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/transfer/edit.blade.php ENDPATH**/ ?>