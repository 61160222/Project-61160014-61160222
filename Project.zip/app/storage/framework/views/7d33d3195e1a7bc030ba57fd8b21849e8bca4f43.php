

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                <table border=1>
                <tr>
                <td>ID</td>
                <td>การเชื่อมต่อ</td>
                <td>คิว</td>
                <td>น้ำหนักบรรทุก</td>
                <td>ข้อยกเว้น</td>
                <td>ล้มเหลวที่</td>

                </tr>
                <?php $__currentLoopData = $failed_jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <tr>
                <td><?php echo e($acc->id); ?></td>
                <td><?php echo e($acc->connection); ?></td>
                <td><?php echo e($acc->queue); ?></td>
                <td><?php echo e($acc->payload); ?></td>
                <td><?php echo e($acc->exception); ?></td>
                <td><?php echo e($acc->failed_at); ?></td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('failed_jobs.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/failed_jobs/index.blade.php ENDPATH**/ ?>